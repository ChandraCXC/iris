
imager = None

def close(*args, **kwargs):
    pass

def delete_frames(*args, **kwargs):
    pass
        
def get_region(*args, **kwargs):
    pass
    
def image(*args, **kwargs):
    pass

def _set_wcs(*args, **kwargs):
    pass

def wcs(*args, **kwargs):
    pass

def open(*args, **kwargs):
    pass

def set_region(*args, **kwargs):
    pass

def xpaget(*args, **kwargs):
    pass

def xpaset(*args, **kwargs):
    pass
